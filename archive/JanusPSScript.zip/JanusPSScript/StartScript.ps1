Start-Process powershell.exe -ArgumentList ".\FileMonitor.ps1"
Start-Sleep -Seconds 5
Start-Process powershell.exe -ArgumentList ".\StringChecker.ps1"
